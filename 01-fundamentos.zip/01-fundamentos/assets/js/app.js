// console.log(console.log('Hola Mundo'));


//console.log(console.log('Hola Mundo'));

// let a=10; // esta es la forma moderna de declarar variables
// var b=10; // esta era la forma antigua de declarar variables
//const c=10;

// c=20; //esto no se puede hacer 

// a=20;
// b=30;// esto fue ejercicio de ejemplo

//let a = 10,
   // b = 20,
    //c = 10,
   // d = 10,
    //x = a+ b;

//console.log( x );
//console.warn( x );
//console.error( x );

// declaramos como variables

// a = 10,
// b = 20,
// c = 30,
// d = 40,
// x = a+ b;

// console.log('a', a );
// console.log('b', b );
// console.log('c', c );

//Declaramos lo mismo como objetos//

// console.log( { a } );
// console.log( { b } );
// console.log( { c } );


//Le agregamos estilo a nuestro console.log
//    console.log('%c Mis variables', 'color:blue; font-weight: bold');
//    console.log( { a } );
//    console.log( { b } );
//    console.log( { c } );

console.log( miNuevoNombre + ' Grajales ' );

alert('Hola desde app.js');

/* console.log( console.log ('Hola mundo')); */

let a = 10,
    b = 20,
    c = 'Hola ',
    d = 'Spiderman',
    x = a+ b;

    /* console.table({a, b, c, d, x});
 */

    const saludo = c + d;

   // constantes es una variable a la que no pienso cambiarle el valor (variable)
   /*  y son mas ligeras que una variable con let o var. y esa es su principal ventaja
    En java Scrip solo se capitalizan las constantes de entorno a diferencia
    de otyrso lenjuages de programación */

c = 'Hola de nuevo'; //


var miNombre= 'beatriz';   // miNombre esta dentro de un obajeto global llamdo window

let outerwidth= 'beatriz2'; 

var miNuevoNombre= 'BeatrizArellano';
 


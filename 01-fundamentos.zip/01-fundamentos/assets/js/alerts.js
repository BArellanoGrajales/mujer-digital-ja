
/* alert('Hola Mundo'); */

/* console.log( miNombre ); */

/* prompt( '¿Cual es tu nombre?', 'sin nombreb' ); */

/* let nombre = prompt('¿Cual es tu nombre?', 'Sin nombre'); */


/* let nombre = prompt('¿Cual es tu nombre?');
console.log( nombre ); // ESto hace que se agrege un Null cuando 
console.log( '****' + nombre + '****' );  // esto es un sting vasio, no es un undefine o un valor nulo
 */

/* const seleccion = confirm ('¿Esta seguro de borrar esto?'); //  esto no corre en la terminal local de node unicamente en el navegador web
console.log( seleccion ); // esto no corre en la terminal local de node unicamente en el navegador web */


let nombre = 'Peter Parker'; //Peter parker es un string por que esta dentro de las comillas simples
console.log( nombre );

nombre = 'Ben Parker'; //Ben parker es un string por que esta dentro de las comillas simples
console.log( nombre );

//otras maneras de inciar strings que son exactamente iguales
nombre="Tia May"; //Tia May es un string por que esta dentro de las comillas dobles
noombre='Tia May'; //Tia May es un string por que esta dentro de las comillas simples


//para saber que tipo de dato apunta una variable se usa el typeof
console.log( typeof nombre ); // typeof es un operador interno que ya existe dentro de JS. y nombre es el nombre de la variable

